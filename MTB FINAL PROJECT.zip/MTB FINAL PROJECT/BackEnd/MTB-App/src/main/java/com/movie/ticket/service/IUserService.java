package com.movie.ticket.service;

import com.movie.ticket.bean.User;
import com.movie.ticket.exception.UserCreationError;

public interface IUserService {

	public User addUser(User user) throws UserCreationError;

	public User removeUser(User user);
}
