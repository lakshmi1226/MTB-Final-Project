package com.movie.ticket.service;

import java.time.LocalDate;
import java.util.List;

import com.movie.ticket.bean.Booking;
import com.movie.ticket.bean.Screen;
import com.movie.ticket.exception.BookingNotFoundException;
import com.movie.ticket.exception.ScreenNotFoundException;

public interface IBookingService {
	public Booking addBooking(Booking booking, Integer customerId,Integer showId) throws BookingNotFoundException;

	public List<Booking> viewBookingList() throws BookingNotFoundException;

	public Booking updateBooking(Booking booking) throws BookingNotFoundException;

	public Booking cancelBooking(int bookingid) throws BookingNotFoundException;

	public List<Booking> showAllBookings(int movieid) throws BookingNotFoundException;
	public Booking viewBooking(int bookingid) throws BookingNotFoundException;
	public List<Booking> showAllBookings(LocalDate bookingdate) throws BookingNotFoundException;

	public double calculateTotalCost(int bookingid);

}
