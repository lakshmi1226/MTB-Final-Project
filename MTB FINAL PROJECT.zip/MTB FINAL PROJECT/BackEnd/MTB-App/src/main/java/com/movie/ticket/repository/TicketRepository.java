package com.movie.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.ticket.bean.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Integer> {

}
