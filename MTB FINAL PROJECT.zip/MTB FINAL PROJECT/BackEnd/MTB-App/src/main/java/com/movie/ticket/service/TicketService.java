package com.movie.ticket.service;

import java.util.List;

import com.movie.ticket.bean.Ticket;
import com.movie.ticket.exception.TicketNotFoundException;

public interface TicketService {
	public Ticket addTicket(Ticket ticket,Integer bookingId) throws TicketNotFoundException;

	public Ticket findTicket(int ticketId);

	List<Ticket> viewTicketList() throws TicketNotFoundException;

}
