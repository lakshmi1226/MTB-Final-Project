package com.movie.ticket.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.movie.ticket.bean.Movie;

@Repository
public interface MoviesRepository extends JpaRepository<Movie, Integer> {
	
	List<Movie> getAllBymovieDate(LocalDate date);

}
