package com.movie.ticket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.movie.ticket.bean.Screen;

public interface ScreenRepository extends JpaRepository<Screen, Integer> {

}
