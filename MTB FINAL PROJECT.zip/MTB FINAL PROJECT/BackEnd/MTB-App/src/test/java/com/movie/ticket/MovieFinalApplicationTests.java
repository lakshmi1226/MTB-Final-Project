package com.movie.ticket;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.movie.ticket.controller.LoginController;
import com.movie.ticket.bean.Booking;
import com.movie.ticket.bean.Customer;
import com.movie.ticket.bean.Movie;
import com.movie.ticket.bean.Screen;
import com.movie.ticket.bean.Seat;
import com.movie.ticket.bean.Show;
import com.movie.ticket.bean.Theatre;
import com.movie.ticket.bean.Ticket;

@SpringBootTest
class MovieFinalApplicationTests extends AbstractTest {
	@Override
	@BeforeEach
	public void setUp() {
		super.setUp();
	}

	@Autowired
	LoginController loginController;
	
	 /* @Test public void addCustomer() throws Exception { String uri =
	 "/customer/add"; Customer cu=new Customer("Vicky", "Pune", "8527419631",
	  "vicky123@gmail.com", "Vicky123"); String inputJson = super.mapToJson(cu);
	  System.out.println("======================="+inputJson+
	  "======================"); MvcResult mvcResult = mvc.perform(
	  MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE
	  ).content(inputJson)) .andReturn(); int status =
	  mvcResult.getResponse().getStatus(); assertEquals(201, status); }
	  */
	 

	@Test
	public void viewCustomerList() throws Exception {
		loginController.loginUser("Jaya", "Jaya123");
		String uri = "/customer/findall";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Customer cu[] = super.mapFromJson(content, Customer[].class);
		assertEquals("Suma",cu[0].getCustomerName());
	}

	@Test
	public void findTheatres() throws Exception {
		String uri = "/theatre/find/52";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Theatre Th = super.mapFromJson(content, Theatre.class);
		assertEquals("A Theatre", Th.getTheatreName());
	}

	@Test
	public void viewMovieList() throws Exception {
		String uri = "/movies/findall";
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri)).andReturn();
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		String content = mvcResult.getResponse().getContentAsString();
		Movie mv[] = super.mapFromJson(content, Movie[].class);
		assertEquals("Bachelor", mv[mv.length-1].getMovieName());
	}


}